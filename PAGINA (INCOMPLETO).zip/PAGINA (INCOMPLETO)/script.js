/*Propiedades del Usuario desplagar acciones*/
let profileDropdonList = document.querySelector(".profile-dropdown-list");
let btn = document.querySelector(".profile-dropdown-btn");

const toggle = ()=> profileDropdonList.classList.toggle("active");

window.addEventListener('click', function(e){
    if(!btn.contains(e.target))profileDropdonList.classList.remove('active');
});

/*Propiedades del Menu de Seleccion de Materia*/
const optionMenu = document.querySelector(".select-menu"),
    selectBtn = optionMenu.querySelector(".select-btn"),
    options = optionMenu.querySelectorAll(".option"),
    sBtn_text = optionMenu.querySelector(".sBtn-text");

selectBtn.addEventListener("click", ()=> optionMenu.classList.toggle("active"));

options.forEach(option =>{
    option.addEventListener("click", ()=>{
        let selectedOption = option.querySelector(".option-text").innerText;
        sBtn_text.innerText = selectedOption;
        optionMenu.classList.remove("active");
    })
})
/*Propiedades del Menu de Busqueda*/
const button = docum.querySelector(".button");
    button.addEventListener("mousedown", () => button.classList.add("clicked"));
    button.addEventListener("mouseup", () => button.classList.remove("clicked"));